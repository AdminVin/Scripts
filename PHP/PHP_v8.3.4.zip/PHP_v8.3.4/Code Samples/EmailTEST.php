<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';

function email_SMTP() {
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Set appropriate debug level
        $mail->CharSet =  "utf-8";
        $mail->isSMTP();
        $mail->Host = "smtp.office365.com";
        $mail->SMTPAuth = true;                  
        $mail->Username = "SENDER@DOMAIN.COM";
        $mail->Password = "PASSWORD";
        $mail->SMTPSecure = "tls";
        $mail->Port = 587;

        $mail->setFrom('SENDER@DOMAIN.COM', 'Mailer');
        $mail->addAddress('RECIPIENT@DOMAIN.com', 'Ellen User');
        $mail->addReplyTo('RECIPIENT@DOMAIN.com', 'Ellen REPLYTO');
        //$mail->addCC('RECIPIENT@DOMAIN.com');
        //$mail->addBCC('RECIPIENT@DOMAIN.com');

        $mail->isHTML(true);
        $mail->Subject = 'PHP - Test Message';
        $mail->Body = '<b>PHP - Test message sent successfuly.</b>';
        $mail->AltBody = 'PHP - Test message sent successfuly.';

        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

email_SMTP();
sleep(5);
	
	
?>